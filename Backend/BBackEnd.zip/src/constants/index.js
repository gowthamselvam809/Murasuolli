const constant = require('./constant');
const indexes = require('./indexes');
const tables = require('./tables');

module.exports = {
    constant,
    indexes,
    tables
}