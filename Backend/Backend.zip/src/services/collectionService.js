const { isEmptyObject, formatErrorResponse } = require('../helper/util');
const { collectionRepository } = require('../repository');


const fetchAllCollection = async (request) => {
    return await collectionRepository.fetchAllCollection(request);
}

const fetchReceiptNo = async (request) => {
    return await collectionRepository.fetchReceiptNo(request);
}

const fetchVoucherNo = async (request) => {
    return await collectionRepository.fetchVoucherNo(request);
}


module.exports = {
    fetchAllCollection,
    fetchReceiptNo,
    fetchVoucherNo
}