const sequelize = require('../../dynamicSequelize');
const { getCurrentTimestamp } = require('../helper/util')
const { collectionModal } = require('../models')


const fetchAllCollection = async (requestData) => {
  const results = await collectionModal(requestData.financial).findAll({
    attributes: ['partyCode', 'docNo', 'voucherNo', 'contraCode', 'docDate', 'dues', 'deposit', 'upTime'],
    raw: true,
  });

  return results.map((item, index) => ({
    ...item,
    id: index + 1
  }));
};

const fetchReceiptNo = async (requestData) => {
  return await sequelize(requestData.financial).query(`
      select max(docno) as receiptNo from Collection where partycode = '${requestData.partyCode}' and Contracode = 'cash'
  `)
}

const fetchVoucherNo = async (requestData) => {
  return await sequelize(requestData.financial).query(`
    select max(voucherno) as voucherNo from Collection where Contracode = 'cash'
  `)
}


module.exports = {
  fetchAllCollection,
  fetchReceiptNo,
  fetchVoucherNo
}