import React from 'react'
import ProcessIssues from '../../components/transaction/processIssues'

const Transaction = () => {
    return (
        <div>
            <ProcessIssues />
        </div>
    )
}

export default Transaction