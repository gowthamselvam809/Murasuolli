import React, { useEffect, useState } from 'react'
import { Button, Col, Container, Form, Row } from 'react-bootstrap'
import DataTable from '../../components/common/dataTable'
import { useForm } from 'react-hook-form';
import { Add, Close } from '@mui/icons-material';
import Select from 'react-dropdown-select';
import { fetchAgentForDropdown, fetchBankForDropdown, fetchReasonForDropdown, fetchReceiptNo, fetchVoucherNo } from '../../api/apiRegister';
import { isEmptyArray } from 'formik';

const ReceiptsPage = () => {
    const { register, handleSubmit, reset, formState: { errors }, setValue } = useForm();
    const [isAdd, setIsAdd] = useState(false);
    const [received, setReceived] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [allAgent, setAllAgent] = useState([]);
    const [allBank, setAllBank] = useState([]);
    const [allReason, setAllReason] = useState([]);
    const [agent, setAgent] = useState([]);
    const [challan, setChallan] = useState('');
    const [receiptNo, setReceiptNo] = useState('');
    const [selectedOption, setSelectedOption] = useState(false);

    const fetchAgent = async () => {
        const response = await fetchAgentForDropdown();
        setAllAgent(response.Items[0]);

        const res = await fetchVoucherNo();
        console.log(res);
        setValue('voucherNo', res.Items[0][0].voucherNo + 1 ?? 1)
        setChallan(res.Items[0][0].voucherNo + 1 ?? 1);
    }

    const fetchBank = async () => {
        const response = await fetchBankForDropdown();
        console.log("banks", response)
        setAllBank(response.Items[0]);
        const res = await fetchReasonForDropdown();
        setAllReason(res.Items[0])
    }

    useEffect(() => {
        fetchAgent();
        fetchBank();

    }, [])

    useEffect(() => {
        if (isEdit) {
            Object.keys(isEdit).forEach((key) => (setValue(key, isEdit[key])));
        }
    }, [isEdit, setValue])

    const handleAgent = async (value) => {
        setAgent(value);
        const response = await fetchReceiptNo({ partyCode: value[0].value });
        console.log(response.Items);
        if (response.Items) {
            console.log("first agent", response.Items[0][0].receiptNo)
            setValue('receiptNo', response.Items[0][0].receiptNo + 1 ?? 1);
            setReceiptNo(response.Items[0][0].receiptNo + 1 ?? 1);
        }

    }

    const handleCancel = () => {
        setIsAdd(false);
        reset();
    }

    const onSubmit = () => {

    }

    const handleRadioChange = (event) => {
        setReceived(event.target.value);
    };

    return (
        <Container className="p-3">
            <Row className="mb-1 px-2">
                <Col>
                    <h3>Receipts</h3>
                </Col>
                <Col align='right'>{
                    !isAdd ? (<Button variant="primary" size="md" onClick={() => setIsAdd(!isAdd)}>
                        Add Receipts <Add style={{ marginLeft: '0.1em' }} />
                    </Button>) : (<Button variant="primary" size="md" onClick={() => handleCancel()}>
                        close<Close style={{ marginLeft: '0.1em' }} />
                    </Button>)
                }</Col>
            </Row>
            {!isAdd ? <DataTable column={[]} row={[]} /> : (
                <Form className='login_form p-2' onSubmit={handleSubmit(onSubmit)}>
                    <Row className="mb-3">
                        {/* <Col xl={3} className='mt-1'>
                            <label>Receipt Date</label>
                        </Col>
                        <Col xl={9}>
                            <input
                                type='date'

                                // value={date}
                                // onChange={(e) => {
                                //     setClicked(false);
                                //     setDate(e.target.value);
                                // }}
                                className='login_form_group px-2'
                            />
                        </Col> */}
                        <Col lg={4} xl={4}>
                            <Form.Group controlId='docDate' >
                                <Form.Label>Receipt Date</Form.Label>
                                <Form.Control className='login_form_group' disabled={isEdit} type='date' placeholder='Enter Reason Code' {...register('docDate', { required: 'Reason Code is required' })} />
                                {errors.docDate && <Form.Text className="text-danger">{errors.docDate.message}</Form.Text>}
                            </Form.Group>
                        </Col>
                        <Col lg={4} xl={4}>
                            <Form.Group controlId='receiptNo' >
                                <Form.Label>Receipt No.</Form.Label>
                                <Form.Control className='login_form_group' disabled={true} style={{ background: '#E6CDCD' }} type='text' placeholder='Enter Reason Name' {...register('receiptNo', { required: 'Reason Name is required' })} />
                                {errors.receiptNo && <Form.Text className="text-danger">{errors.receiptNo.message}</Form.Text>}
                            </Form.Group>
                        </Col>
                        <Col lg={4} xl={4}>
                            <Form.Group controlId='voucherNo' >
                                <Form.Label>Challan No.</Form.Label>
                                <Form.Control className='login_form_group' disabled={true} style={{ background: '#E6CDCD' }} type='text' placeholder='Enter Reason Code' {...register('voucherNo', { required: 'Reason Code is required' })} />
                                {errors.voucherNo && <Form.Text className="text-danger">{errors.voucherNo.message}</Form.Text>}
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row className='mt-3'>
                        <Col lg={6} xl={6}>
                            <Form.Group controlId='partyCode' >
                                <Form.Label>Agent</Form.Label>
                                <Select
                                    className='login_form_group'
                                    options={allAgent}
                                    onChange={(value) => handleAgent(value)}
                                    placeholder="Select a Agent"
                                />
                                {!selectedOption && isEmptyArray(agent) && <Form.Text className="text-danger">Please select a partyCode</Form.Text>}
                            </Form.Group>
                        </Col>
                        {received === 'Bank' && (
                            <Col lg={6} xl={6}>
                                <Form.Group controlId='contraCode' >
                                    <Form.Label>Bank</Form.Label>
                                    <Select
                                        className='login_form_group'
                                        options={allBank}
                                        // onChange={setStatus}
                                        placeholder="Select a Bank"
                                    />
                                    {isEmptyArray() && selectedOption && <Form.Text className="text-danger">Please select a status</Form.Text>}
                                </Form.Group>
                            </Col>)}
                    </Row>
                    <Row className='mt-4'>
                        <Col lg={2} xl={2}>
                            <Form.Label>Received :</Form.Label>
                        </Col>
                        <Col lg={4} xl={4}>
                            <Form.Check
                                inline
                                type='radio'
                                id='Cash'
                                name='received'
                                value='Cash'
                                label='Cash'
                                checked={received === 'Cash'}
                                onChange={handleRadioChange}
                                className='mr-4'
                            />

                            <Form.Check
                                inline
                                type='radio'
                                id='Bank'
                                name='received'
                                value='Bank'
                                label='Bank'
                                checked={received === 'Bank'}
                                onChange={handleRadioChange}
                            />
                        </Col>

                    </Row>
                    <Row className='mt-2'>
                        <Col lg={6} xl={6} >
                            <Form.Group controlId='dues' >
                                <Form.Label>Dues</Form.Label>
                                <Form.Control className='login_form_group' type='text' placeholder='Enter Reason Name' {...register('dues', { required: 'Reason Name is required' })} />
                                {errors.dues && <Form.Text className="text-danger">{errors.dues.message}</Form.Text>}
                            </Form.Group>
                        </Col>
                        <Col lg={6} xl={6} >
                            <Form.Group controlId='deposit' >
                                <Form.Label>Deposit</Form.Label>
                                <Form.Control className='login_form_group' type='text' placeholder='Enter Reason Name' {...register('deposit', { required: 'Reason Name is required' })} />
                                {errors.deposit && <Form.Text className="text-danger">{errors.deposit.message}</Form.Text>}
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row className='mt-3'>
                        <Col lg={6} xl={6}>
                            <Form.Group controlId='reasonName' >
                                <Form.Label>Remarks</Form.Label>
                                <Select
                                    className='login_form_group'
                                    options={allReason}
                                    // onChange={setStatus}
                                    placeholder="Select a Bank"
                                />
                                {errors.reasonName && <Form.Text className="text-danger">{errors.reasonName.message}</Form.Text>}
                            </Form.Group>
                        </Col>
                    </Row>

                    <Row align='right' className="mt-4">
                        <Col >
                            <Button variant='primary' disabled={isLoading} type='submit' className='login_form_button mx-3'>
                                Save
                            </Button>

                            <Button variant='secondary' disabled={isLoading} type='button' onClick={handleCancel} className='login_form_button '>
                                Cancel
                            </Button>
                        </Col>
                    </Row>
                </Form>
            )}
        </Container>
    )
}

export default ReceiptsPage