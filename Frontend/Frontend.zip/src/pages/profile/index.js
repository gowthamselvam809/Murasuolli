import React from "react";
import { ProfileForm } from "../../components/profile";

const Profile = () => {
  return (
    <div className="update-profile__conatiner">
      <ProfileForm />
    </div>
  )
}

export { Profile };