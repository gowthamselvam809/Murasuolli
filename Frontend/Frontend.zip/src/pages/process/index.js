import React from 'react'
// import ProcessIssues from '../../components/transaction/processIssues'
import Process from '../../components/transaction/tabs/process'

const ProcessPage = () => {
    return (
        <div style={{ height: '81vh' }}>
            <Process />
        </div>
    )
}

export default ProcessPage