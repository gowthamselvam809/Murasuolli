import React from "react";
import { UsersList } from "../../components/Common";

const Users = () => {
  return (
    <div className="user__conatiner">
      <UsersList />
    </div>
  )
}

export { Users };