import React from 'react'
import ProcessEdit from '../../components/transaction/tabs/processEdit'

const EditIssue = () => {
    return (
        <div style={{ height: '81vh' }}>
            <ProcessEdit />
        </div>
    )
}

export default EditIssue